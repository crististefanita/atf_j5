package ro.cardtable.ui.hand;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.function.Consumer;
import java.util.function.Predicate;
import ro.cardtable.ui.cards.CardFaceDrawable;
import ro.cardtable.ui.cards.CardFaceMetrics;
import ro.cardtable.ui.cards.CardFaceView;
import ro.cardtable.ui.cards.CardHighlight;
import ro.cardtable.ui.cards.CardHighlightView;

/** Renders a snapshot-bound hand without owning legality or executing a game command. */
public final class HandFan {
    private static final int GOLD = Color.rgb(220, 181, 105);
    private static final int SOFT_BORDER = Color.rgb(211, 220, 210);
    private final Context context;
    private final List<HandCard> cards;
    private final int clearanceDp;
    private final Consumer<String> onCardSelected;
    private final Predicate<HandCard> highlight;
    private final boolean rejectedTapHint;

    public HandFan(Context context, List<HandCard> cards, int clearanceDp, boolean compact, Consumer<String> onCardSelected) {
        this(context, cards, clearanceDp, compact, onCardSelected, card -> false);
    }

    public HandFan(Context context, List<HandCard> cards, int clearanceDp, boolean compact,
            Consumer<String> onCardSelected, Predicate<HandCard> highlight) {
        this(context, cards, clearanceDp, compact, onCardSelected, highlight, false);
    }

    public HandFan(Context context, List<HandCard> cards, int clearanceDp, boolean compact,
            Consumer<String> onCardSelected, Predicate<HandCard> highlight, boolean rejectedTapHint) {
        this.context = context; this.cards = List.copyOf(cards); this.clearanceDp = clearanceDp;
        this.onCardSelected = java.util.Objects.requireNonNull(onCardSelected);
        this.highlight = java.util.Objects.requireNonNull(highlight);
        this.rejectedTapHint = rejectedTapHint;
        if (cards.stream().map(HandCard::id).distinct().count() != cards.size()) throw new IllegalArgumentException("Duplicate visible card identity");
    }
    public View build(int widthPx) {
        int cardCount = cards.size();
        float fontScale = context.getResources().getConfiguration().fontScale;
        FrameLayout fan = new FrameLayout(context);
        fan.setClipChildren(false);
        fan.setClipToPadding(false);
        if (cardCount == 0) return fan;
        var metrics = CardFaceMetrics.atHeight(HandLayoutMetrics.cardHeightDp());
        int indexWidthPx = CardFaceView.indexBandWidthPx(context, metrics);
        HandLayoutMetrics.Fan layout = HandLayoutMetrics.fan(cardCount, widthPx,
                context.getResources().getDisplayMetrics().density, fontScale, indexWidthPx);
        fan.setMinimumWidth(layout.width());
        int cardHeightDp = HandLayoutMetrics.cardHeightDp();
        int liftClearanceDp = clearanceDp;
        fan.setTag("player-hand-fan");
        var input = new HandInput(cards, rejectedTapHint);
        var faces = new LinkedHashMap<HandCard, CardFaceDrawable>();
        float density = context.getResources().getDisplayMetrics().density;
        Runnable repaint = () -> faces.forEach((card, drawable) -> {
            drawable.restoreStyle(card.playable() ? GOLD : SOFT_BORDER);
            if (input.rejects(card)) CardHighlightView.paint(drawable, CardHighlight.REJECTED, density);
            else if (input.suggests(card) || highlight.test(card)) {
                CardHighlightView.paint(drawable, CardHighlight.IN_PLACE, density);
            }
        });
        for (int index = 0; index < cardCount; index++) {
            HandCard card = cards.get(index);
            boolean playable = card.playable();
            FrameLayout slot = new FrameLayout(context);
            slot.setClipChildren(false);
            slot.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            slot.setFocusable(true);
            slot.setTag("hand-card:" + card.id());
            slot.setContentDescription(card.description());
            slot.setEnabled(true);
            slot.setClickable(input.acceptsTap(card));
            slot.setTranslationZ(dp(HandLayoutMetrics.NEIGHBOR_Z_DP));
            var drawable = new CardFaceDrawable(card.face(), density, playable ? GOLD : SOFT_BORDER);
            faces.put(card, drawable);
            FrameLayout face = CardFaceView.build(context, card.face(), drawable, metrics, indexWidthPx);
            FrameLayout.LayoutParams faceParams = new FrameLayout.LayoutParams(layout.cardWidth(),
                    dp(cardHeightDp), Gravity.TOP | Gravity.START);
            faceParams.topMargin = dp(liftClearanceDp);
            slot.addView(face, faceParams);
            if (input.acceptsTap(card)) {
                slot.setOnClickListener(ignored -> {
                    switch (input.tap(card)) {
                        case IGNORE -> { return; }
                        case HINT -> {
                            repaint.run();
                            long revision = input.revision();
                            fan.postDelayed(() -> {
                                if (input.clearHint(revision)) repaint.run();
                            }, HandInput.HINT_DURATION_MILLIS);
                            return;
                        }
                        case PLAY -> repaint.run();
                    }
                    slot.setClickable(false);
                    slot.setTranslationZ(dp(HandLayoutMetrics.SELECTED_Z_DP));
                    face.animate().translationY(-dp(HandLayoutMetrics.CARD_LIFT_DP))
                            .scaleX(HandLayoutMetrics.CARD_LIFT_SCALE)
                            .scaleY(HandLayoutMetrics.CARD_LIFT_SCALE)
                            .setInterpolator(HandLayoutMetrics::liftProgress)
                            .setDuration(HandInput.PLAY_LIFT_MILLIS)
                            .withEndAction(() -> onCardSelected.accept(card.id()))
                            .start();
                });
            }
            FrameLayout.LayoutParams slotParams = new FrameLayout.LayoutParams(
                    index == cardCount - 1 ? layout.cardWidth() : layout.advance(),
                    HandLayoutMetrics.slotHeightPx(
                            context.getResources().getDisplayMetrics().density, clearanceDp));
            slotParams.leftMargin = layout.left(index);
            fan.addView(slot, slotParams);
        }
        repaint.run();
        return fan;
    }
    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

}
