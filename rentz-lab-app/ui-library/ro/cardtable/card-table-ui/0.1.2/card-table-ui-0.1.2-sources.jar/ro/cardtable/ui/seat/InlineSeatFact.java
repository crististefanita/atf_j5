package ro.cardtable.ui.seat;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

/** A fact stays together even when the fixed seat is narrower than the measured text. */
final class InlineSeatFact extends TextView {
    InlineSeatFact(Context context, SeatContent.Fact fact, int color, boolean compact) {
        super(context);
        var text = new SpannableString(fact.inlineText());
        text.setSpan(new StyleSpan(Typeface.BOLD), fact.label().length() + 1, text.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        setText(text);
        setTextSize(11);
        setTextColor(color);
        setGravity(Gravity.CENTER);
        setIncludeFontPadding(!compact);
        setSingleLine(true);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        var paint = new TextPaint(getPaint());
        paint.setTextScaleX(1);
        int available = MeasureSpec.getSize(widthSpec) - getCompoundPaddingLeft() - getCompoundPaddingRight();
        float natural = Layout.getDesiredWidth(getText(), paint);
        float scale = MeasureSpec.getMode(widthSpec) == MeasureSpec.UNSPECIFIED || natural <= 0
                ? 1 : Math.min(1, Math.max(0, available) / (float) Math.ceil(natural));
        if (scale != getTextScaleX()) setTextScaleX(scale);
        super.onMeasure(widthSpec, heightSpec);
    }
}
