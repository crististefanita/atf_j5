package ro.cardtable.ui.table.android;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import ro.cardtable.ui.table.TableGeometry;
import ro.cardtable.ui.table.TableSizing;
import ro.cardtable.ui.table.TableViewportPolicy;

/** Owns all occupied table regions so controls cannot silently cover a player's seat. */
public class BoardLayout extends ViewGroup {
    private final int players;
    private final int centerWidthDp;
    private final int minimumHeightDp;
    private final int regionGapDp;
    private final boolean compact;
    private final boolean centerUsesFullWidth;
    private final int reservedCenterHeightDp;
    private final boolean stableSeatAnchors;
    private final int requestedHandClearanceDp;
    private final TableGeometry.CenterAlignment centerAlignment;
    private TableGeometry.BoardSpec board;

    public BoardLayout(Context context, int players, int centerWidthDp, TableViewportPolicy viewport,
            boolean centerUsesFullWidth, TableGeometry.CenterAlignment centerAlignment) {
        this(context, players, centerWidthDp, viewport, centerUsesFullWidth, 0, false, centerAlignment);
    }

    /** Reserves a phase-independent center band and optional play-phase seat anchors. */
    public BoardLayout(Context context, int players, int centerWidthDp, TableViewportPolicy viewport,
            boolean centerUsesFullWidth, int reservedCenterHeightDp, boolean stableSeatAnchors,
            TableGeometry.CenterAlignment centerAlignment) {
        this(context, players, centerWidthDp, viewport, centerUsesFullWidth, reservedCenterHeightDp,
                stableSeatAnchors, centerAlignment, 0);
    }

    /** Keeps a requested gap above the player's hand when the measured board has spare height. */
    public BoardLayout(Context context, int players, int centerWidthDp, TableViewportPolicy viewport,
            boolean centerUsesFullWidth, int reservedCenterHeightDp, boolean stableSeatAnchors,
            TableGeometry.CenterAlignment centerAlignment, int requestedHandClearanceDp) {
        super(context);
        if (reservedCenterHeightDp < 0 || requestedHandClearanceDp < 0) {
            throw new IllegalArgumentException("Reserved table dimensions cannot be negative");
        }
        this.players = players;
        this.centerWidthDp = centerWidthDp;
        this.minimumHeightDp = viewport.minimumBoardHeightDp();
        this.regionGapDp = viewport.regionGapDp();
        this.compact = viewport.isCompact();
        this.centerUsesFullWidth = centerUsesFullWidth;
        this.reservedCenterHeightDp = reservedCenterHeightDp;
        this.stableSeatAnchors = stableSeatAnchors;
        this.requestedHandClearanceDp = requestedHandClearanceDp;
        this.centerAlignment = centerAlignment;
        setClipChildren(false);
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int gap = dp(regionGapDp);
        int seatWidth = dp(TableSizing.seatWidthDp(
                Math.round(width / getResources().getDisplayMetrics().density), compact));
        int seatHeight = 0;
        for (int index = 0; index < players; index++) {
            View seat = getChildAt(index);
            seat.measure(MeasureSpec.makeMeasureSpec(seatWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            seatHeight = Math.max(seatHeight, seat.getMeasuredHeight());
        }
        for (int index = 0; index < players; index++) {
            getChildAt(index).measure(MeasureSpec.makeMeasureSpec(seatWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(seatHeight, MeasureSpec.EXACTLY));
        }
        View center = getChildAt(players);
        int measuredCenterWidth = centerUsesFullWidth ? width : Math.min(width, dp(centerWidthDp));
        center.measure(MeasureSpec.makeMeasureSpec(measuredCenterWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        var centerSpec = new TableGeometry.CenterSpec(dp(centerWidthDp), dp(reservedCenterHeightDp),
                centerUsesFullWidth, centerAlignment);
        board = new TableGeometry.BoardSpec(players, seatWidth, seatHeight, centerSpec,
                gap, dp(minimumHeightDp), dp(requestedHandClearanceDp), stableSeatAnchors);
        int minimum = board.requiredHeight(center.getMeasuredHeight());
        setMeasuredDimension(width, Math.max(minimum, resolveSize(minimum, heightSpec)));
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        View center = getChildAt(players);
        var plan = board.plan(right - left, bottom - top, center.getMeasuredHeight());
        for (int index = 0; index < players; index++) place(getChildAt(index), plan.seats().get(index));
        place(center, board.content(plan, center.getMeasuredWidth(), center.getMeasuredHeight()));
    }

    private static void place(View view, TableGeometry.Rect box) {
        view.layout(box.left(), box.top(), box.right(), box.bottom());
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override protected LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
    }
}
